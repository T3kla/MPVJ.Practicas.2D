#pragma once

struct GameObject
{
    bool isActive = true;
};
