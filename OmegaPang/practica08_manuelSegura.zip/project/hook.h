#pragma once

struct Hook
{
    bool enable = true;

    float speed = 100.f;
};
