#include "scene_loader.h"

SceneLoader SceneLoader::Instance;
