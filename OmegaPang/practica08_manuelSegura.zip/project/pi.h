#pragma once

constexpr double PI = 355. / 113.;

double ToDeg(const double &rad);
double ToRad(const double &deg);
