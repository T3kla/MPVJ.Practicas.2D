#pragma once

struct Camera
{
    bool enable = true;

    bool main = false;
    float height = 1.f;
};
