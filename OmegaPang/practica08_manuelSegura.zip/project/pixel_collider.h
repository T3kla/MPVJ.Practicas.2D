#pragma once

#include "collider.h"

struct PixelCollider : public Collider
{
};
