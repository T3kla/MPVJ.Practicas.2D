#pragma once

struct Explosion
{
    bool enable = true;

    float lifespan = 0.5f;
    Size size = Size::S;
};
