#pragma once

struct Bee
{
    bool enable = true;
};
